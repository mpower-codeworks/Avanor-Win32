@echo off
if exist obj_winapi rmdir /s /q obj_winapi
if exist bin\AvanorWinAPI.exe del /q bin\AvanorWinAPI.exe
if exist bin\AvanorWin32.exe del /q bin\AvanorWin32.exe
if exist obj_winapi\avanor_icon.res del /q obj_winapi\avanor_icon.res

if exist bin\*.ttf del /q bin\*.ttf
if exist bin\*.otf del /q bin\*.otf
if exist bin\fonts rmdir /s /q bin\fonts
