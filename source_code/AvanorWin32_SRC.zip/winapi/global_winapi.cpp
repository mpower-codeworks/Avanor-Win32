/*

    / / / / / / / / / / / / /
  / / global_winapi.cpp / /
/ / / / / / / / / / / / /

native Win32/GDI window 

*/

#include <windows.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "global.h"
#include "resource.h"

unsigned long total_cr  = 0;
unsigned long total_it  = 0;
unsigned long cr_kiled  = 0;
unsigned long cr_died   = 0;

const char* color_convert_table[] =
{
    "\x1F\x00", "\x1F\x01", "\x1F\x02", "\x1F\x03",
    "\x1F\x04", "\x1F\x05", "\x1F\x06", "\x1F\x07",
    "\x1F\x08", "\x1F\x09", "\x1F\x0A", "\x1F\x0B",
    "\x1F\x0C", "\x1F\x0D", "\x1F\x0E", "\x1F\x0F",
};

int __animation_flag = 100;

long size_x = 80;
long size_y = 25;

static int cursor_pos_x     = 0;
static int cursor_pos_y     = 0;
static int current_attr     = 7;
static int cursor_visible   = 0;
static int draw_cursor_line = 0;

struct AV_CELL
{
    char ch;
    unsigned char attr;
};

static AV_CELL *vscreen               = NULL;

static HINSTANCE g_hInstance          = NULL;
static HWND      g_hwnd               = NULL;
static HANDLE    g_windowThread       = NULL;
static DWORD     g_windowThreadId     = 0;
static HANDLE    g_windowReady        = NULL;
static HANDLE    g_keyReady           = NULL;
static volatile LONG g_closing        = 0;
static volatile LONG g_finiting       = 0;
static volatile LONG g_refreshPending = 0;

static CRITICAL_SECTION g_screenLock;
static CRITICAL_SECTION g_keyLock;

#define AV_KEY_QUEUE_SIZE 256
static int g_keyQueue[AV_KEY_QUEUE_SIZE];
static int g_keyHead  = 0;
static int g_keyTail  = 0;
static int g_keyCount = 0;

static HFONT g_font             = NULL;
static HBRUSH g_backgroundBrush = NULL;
static HCURSOR g_arrowCursor    = NULL;
static HBITMAP g_tileBitmap     = NULL;
static int g_tileBitmapW        = 0;
static int g_tileBitmapH        = 0;
static int g_tileBackgroundOn   = 0;
static int g_startFullscreen    = 1;
static int g_charW              = 10;
static int g_charH              = 18;
static int g_fontPixelHeight    = 18;
static int g_termLeft           = 16;
static int g_termTop            = 16;
static const int g_margin       = 0;
static const int g_minFontPixelHeight = 8;
static const int g_maxFontPixelHeight = 96;

static int g_fullscreen               = 0;
static DWORD g_savedWindowStyle       = 0;
static DWORD g_savedWindowExStyle     = 0;
static WINDOWPLACEMENT g_savedWindowPlacement = { sizeof(WINDOWPLACEMENT) };

static void ApplyDarkModeToWindow(HWND hwnd)
{
    typedef HRESULT (WINAPI *DWMSETWINDOWATTRIBUTEPROC)(HWND, DWORD, LPCVOID, DWORD);
    HMODULE dwmapi;
    DWMSETWINDOWATTRIBUTEPROC pDwmSetWindowAttribute;
    BOOL useDarkMode = TRUE;
    HRESULT hr;

    if (!hwnd)
        return;

    dwmapi = LoadLibraryA("dwmapi.dll");
    if (!dwmapi)
        return;

    pDwmSetWindowAttribute = (DWMSETWINDOWATTRIBUTEPROC)GetProcAddress(dwmapi, "DwmSetWindowAttribute");
    if (pDwmSetWindowAttribute)
    {
        hr = pDwmSetWindowAttribute (
            hwnd,
            20,
            &useDarkMode,
            sizeof(useDarkMode)
        );

        if (hr != S_OK)
            pDwmSetWindowAttribute(hwnd, 19, &useDarkMode, sizeof(useDarkMode));
    }

    FreeLibrary(dwmapi);
}

#define AV_MAX_PRIVATE_FONTS 32

static char g_exeDir[MAX_PATH] = { 0 };
static char g_privateFontPaths[AV_MAX_PRIVATE_FONTS][MAX_PATH];
static int g_privateFontLoaded[AV_MAX_PRIVATE_FONTS];
static int g_privateFontCount = 0;
static const char *g_fontFace = "Nouveau IBM";
static const char *g_fallbackFontFace = "Consolas";

static const char *g_fontChoices[] =
{
    "Nouveau IBM",
    "Ac437 ATI 8x16",
    "Kode Mono",
    "Berkelium HGR II",    
    "Space Mono",
    "Consolas",
    "Lucida Console",
    "Courier New"
};

static int g_fontChoice = 0;
static const int g_fontChoiceCount = sizeof(g_fontChoices) / sizeof(g_fontChoices[0]);

#define AV_WM_REFRESH (WM_APP + 1)

static COLORREF AvColor(int color)
{
    static COLORREF table[16] =
    {
        RGB(  0,   0,   0), RGB(  0,   0, 170), RGB(  0, 170,   0), RGB(  0, 170, 170),
        RGB(170,   0,   0), RGB(170,   0, 170), RGB(170,  85,   0), RGB(170, 170, 170),
        RGB( 85,  85,  85), RGB( 85,  85, 255), RGB( 85, 255,  85), RGB( 85, 255, 255),
        RGB(255,  85,  85), RGB(255,  85, 255), RGB(255, 255,  85), RGB(255, 255, 255)
    };

    return table[color & 15];
}

static void QueueKey(int key)
{
    EnterCriticalSection(&g_keyLock);

    if (g_keyCount < AV_KEY_QUEUE_SIZE)
    {
        g_keyQueue[g_keyTail] = key;
        g_keyTail = (g_keyTail + 1) % AV_KEY_QUEUE_SIZE;
        g_keyCount++;
        SetEvent(g_keyReady);
    }

    LeaveCriticalSection(&g_keyLock);
}

static int DequeueKey(int *key)
{
    int got = 0;

    EnterCriticalSection(&g_keyLock);

    if (g_keyCount > 0)
    {
        *key = g_keyQueue[g_keyHead];
        g_keyHead = (g_keyHead + 1) % AV_KEY_QUEUE_SIZE;
        g_keyCount--;
        got = 1;
    }

    if (g_keyCount == 0)
        ResetEvent(g_keyReady);

    LeaveCriticalSection(&g_keyLock);

    return got;
}

static int QueueHasKey()
{
    int result;

    EnterCriticalSection(&g_keyLock);
    result = g_keyCount > 0;
    LeaveCriticalSection(&g_keyLock);

    return result;
}

static int FileExistsA(const char *path)
{
    DWORD attr = GetFileAttributesA(path);
    return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
}

static void BuildExeDirectory()
{
    DWORD len;
    char *slash;

    g_exeDir[0] = 0;
    len = GetModuleFileNameA(NULL, g_exeDir, MAX_PATH);

    if (len == 0 || len >= MAX_PATH)
    {
        strcpy(g_exeDir, ".\\");
        return;
    }

    slash = strrchr(g_exeDir, '\\');
    if (!slash)
    {
        strcpy(g_exeDir, ".\\");
        return;
    }

    slash[1] = 0;
}

static void BuildExeRelativePath(const char *relativePath, char *outPath)
{
    outPath[0] = 0;

    if (!g_exeDir[0])
        BuildExeDirectory();

    strncpy(outPath, g_exeDir, MAX_PATH - 1);
    outPath[MAX_PATH - 1] = 0;
    strncat(outPath, relativePath, MAX_PATH - strlen(outPath) - 1);
}

static void BuildExeSiblingPath(const char *fileName, char *outPath)
{
    BuildExeRelativePath(fileName, outPath);
}

static void LoadPrivateFonts()
{
    WIN32_FIND_DATAA findData;
    HANDLE findHandle;
    char searchPath[MAX_PATH];
    char fontPath[MAX_PATH];
    int loaded;

    BuildExeDirectory();

    /* =========================================================
    ** font files live in a fonts folder beside AvanorWin32.exe:
    ** bin\AvanorWin32.exe
    ** bin\fonts\*.ttf
    ** =========================================================
    */
    BuildExeRelativePath("fonts\\*.ttf", searchPath);

    findHandle = FindFirstFileA(searchPath, &findData);
    if (findHandle == INVALID_HANDLE_VALUE)
        return;

    do
    {
        if (!(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && g_privateFontCount < AV_MAX_PRIVATE_FONTS)
        {
            BuildExeRelativePath("fonts\\", fontPath);
            strncat(fontPath, findData.cFileName, MAX_PATH - strlen(fontPath) - 1);

            if (FileExistsA(fontPath))
            {
                loaded = AddFontResourceExA(fontPath, FR_PRIVATE, NULL);
                if (!loaded)
                    loaded = AddFontResourceA(fontPath);

                if (loaded)
                {
                    strncpy(g_privateFontPaths[g_privateFontCount], fontPath, MAX_PATH - 1);
                    g_privateFontPaths[g_privateFontCount][MAX_PATH - 1] = 0;
                    g_privateFontLoaded[g_privateFontCount] = loaded;
                    g_privateFontCount++;
                }
            }
        }
    }
    while (FindNextFileA(findHandle, &findData));

    FindClose(findHandle);
}

static void UnloadPrivateFonts()
{
    int i;

    for (i = g_privateFontCount - 1; i >= 0; i--)
    {
        if (g_privateFontLoaded[i] && g_privateFontPaths[i][0])
        {
            if (!RemoveFontResourceExA(g_privateFontPaths[i], FR_PRIVATE, NULL))
                RemoveFontResourceA(g_privateFontPaths[i]);

            g_privateFontLoaded[i] = 0;
            g_privateFontPaths[i][0] = 0;
        }
    }

    g_privateFontCount = 0;
}

static void LoadTileBackground()
{
    char bitmapPath[MAX_PATH];
    BITMAP bitmapInfo;

    BuildExeSiblingPath("bkground\\blk_marble.bmp", bitmapPath);

    if (!FileExistsA(bitmapPath))
        return;

    g_tileBitmap = (HBITMAP)LoadImageA(NULL, bitmapPath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
    if (!g_tileBitmap)
        return;

    if (GetObject(g_tileBitmap, sizeof(bitmapInfo), &bitmapInfo))
    {
        g_tileBitmapW = bitmapInfo.bmWidth;
        g_tileBitmapH = bitmapInfo.bmHeight;
    }

    if (g_tileBitmapW <= 0 || g_tileBitmapH <= 0)
    {
        DeleteObject(g_tileBitmap);
        g_tileBitmap = NULL;
        g_tileBitmapW = 0;
        g_tileBitmapH = 0;
    }
}

static void UnloadTileBackground()
{
    if (g_tileBitmap)
    {
        DeleteObject(g_tileBitmap);
        g_tileBitmap = NULL;
    }

    g_tileBitmapW = 0;
    g_tileBitmapH = 0;
}

static void TileBackgroundToDC(HDC hdc, const RECT *client)
{
    HDC srcDC;
    HBITMAP oldBitmap;
    int x;
    int y;

    if (!g_tileBitmap || g_tileBitmapW <= 0 || g_tileBitmapH <= 0)
        return;

    srcDC = CreateCompatibleDC(hdc);
    if (!srcDC)
        return;

    oldBitmap = (HBITMAP)SelectObject(srcDC, g_tileBitmap);

    for (y = client->top; y < client->bottom; y += g_tileBitmapH)
    {
        for (x = client->left; x < client->right; x += g_tileBitmapW)
        {
            BitBlt(hdc, x, y, g_tileBitmapW, g_tileBitmapH, srcDC, 0, 0, SRCCOPY);
        }
    }

    SelectObject(srcDC, oldBitmap);
    DeleteDC(srcDC);
}

static int CALLBACK AvanorFontEnumProc(const LOGFONTA *logFont, const TEXTMETRICA *textMetric, DWORD fontType, LPARAM param)
{
    int *found = (int *)param;

    (void)logFont;
    (void)textMetric;
    (void)fontType;

    *found = 1;
    return 0;
}

static int FontFaceAvailable(HWND hwnd, const char *faceName)
{
    HDC hdc;
    LOGFONTA lf;
    int found = 0;

    if (!hwnd || !faceName || !faceName[0])
        return 0;

    memset(&lf, 0, sizeof(lf));
    lf.lfCharSet = DEFAULT_CHARSET;
    strncpy(lf.lfFaceName, faceName, LF_FACESIZE - 1);
    lf.lfFaceName[LF_FACESIZE - 1] = 0;

    hdc = GetDC(hwnd);
    if (!hdc)
        return 0;

    EnumFontFamiliesExA(hdc, &lf, AvanorFontEnumProc, (LPARAM)&found, 0);

    ReleaseDC(hwnd, hdc);
    return found;
}

static int FindAvailableFontChoice(HWND hwnd, int startChoice, int direction)
{
    int i;
    int choice;

    if (g_fontChoiceCount <= 0)
        return -1;

    if (direction == 0)
        direction = 1;

    choice = startChoice;

    for (i = 0; i < g_fontChoiceCount; i++)
    {
        while (choice < 0)
            choice += g_fontChoiceCount;

        while (choice >= g_fontChoiceCount)
            choice -= g_fontChoiceCount;

        if (FontFaceAvailable(hwnd, g_fontChoices[choice]))
            return choice;

        choice += direction;
    }

    return -1;
}

static HFONT CreateAvanorFont(int pixelHeight, const char *faceName)
{
    return CreateFontA(
        -pixelHeight, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN, faceName);
}

static void MeasureFontHandle(HWND hwnd, HFONT font, int *charW, int *charH)
{
    HDC hdc = GetDC(hwnd);
    HFONT oldFont;
    TEXTMETRICA tm;

    oldFont = (HFONT)SelectObject(hdc, font);
    GetTextMetricsA(hdc, &tm);
    *charW = tm.tmAveCharWidth;
    *charH = tm.tmHeight;
    SelectObject(hdc, oldFont);
    ReleaseDC(hwnd, hdc);
}

static void ReplaceCurrentFont(HFONT newFont, int pixelHeight, int charW, int charH)
{
    if (g_font)
        DeleteObject(g_font);

    g_font = newFont;
    g_fontPixelHeight = pixelHeight;
    g_charW = charW;
    g_charH = charH;
}

static void FitFontToClient(HWND hwnd)
{
    RECT client;
    int clientW;
    int clientH;
    int availW;
    int availH;
    int heightGuess;
    int h;
    HFONT testFont = NULL;
    HFONT bestFont = NULL;
    int testW = 10;
    int testH = 18;
    int bestW = 10;
    int bestH = 18;
    int bestPixelHeight = 18;
    const char *faceName;

    GetClientRect(hwnd, &client);
    clientW = client.right - client.left;
    clientH = client.bottom - client.top;

    availW = clientW - g_margin * 2;
    availH = clientH - g_margin * 2;

    if (availW < 1)
        availW = 1;
    if (availH < 1)
        availH = 1;

    heightGuess = availH / (int)size_y;

    if (heightGuess < g_minFontPixelHeight)
        heightGuess = g_minFontPixelHeight;
    if (heightGuess > g_maxFontPixelHeight)
        heightGuess = g_maxFontPixelHeight;

    {
        int availableChoice;

        availableChoice = FindAvailableFontChoice(hwnd, g_fontChoice, 1);
        if (availableChoice >= 0)
        {
            g_fontChoice = availableChoice;
            faceName = g_fontChoices[g_fontChoice];
        }
        else
        {
            faceName = g_fallbackFontFace;
        }
    }

    for (h = heightGuess; h >= g_minFontPixelHeight; h--)
    {
        testFont = CreateAvanorFont(h, faceName);
        if (!testFont)
            continue;

        MeasureFontHandle(hwnd, testFont, &testW, &testH);

        if (testW * size_x <= availW && testH * size_y <= availH)
        {
            bestFont = testFont;
            bestW = testW;
            bestH = testH;
            bestPixelHeight = h;
            break;
        }

        DeleteObject(testFont);
        testFont = NULL;
    }

    if (!bestFont)
    {
        bestPixelHeight = g_minFontPixelHeight;
        bestFont = CreateAvanorFont(bestPixelHeight, faceName);
        if (!bestFont)
            return;
        MeasureFontHandle(hwnd, bestFont, &bestW, &bestH);
    }

    ReplaceCurrentFont(bestFont, bestPixelHeight, bestW, bestH);

    g_termLeft = (clientW - (int)(size_x * g_charW)) / 2;
    g_termTop = (clientH - (int)(size_y * g_charH)) / 2;

    if (g_termLeft < 0)
        g_termLeft = 0;
    if (g_termTop < 0)
        g_termTop = 0;
}

static void MeasureFont(HWND hwnd)
{
    FitFontToClient(hwnd);
}

static void SwitchAvanorFont(HWND hwnd, int direction)
{
    int oldChoice;
    int startChoice;
    int availableChoice;

    if (g_fontChoiceCount <= 1)
        return;

    oldChoice = g_fontChoice;
    startChoice = g_fontChoice + direction;
    availableChoice = FindAvailableFontChoice(hwnd, startChoice, direction);

    if (availableChoice < 0 || availableChoice == oldChoice)
        return;

    g_fontChoice = availableChoice;

    FitFontToClient(hwnd);
    InvalidateRect(hwnd, NULL, FALSE);
}

static void ToggleTileBackground(HWND hwnd)
{
    if (!g_tileBitmap)
        return;

    g_tileBackgroundOn = !g_tileBackgroundOn;
    InvalidateRect(hwnd, NULL, FALSE);
}

static void SizeWindowForScreen(HWND hwnd)
{
    RECT rc;

    rc.left = 0;
    rc.top = 0;
    rc.right = (LONG)(size_x * g_charW + g_margin * 2);
    rc.bottom = (LONG)(size_y * g_charH + g_margin * 2);

    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);

    SetWindowPos(hwnd, NULL, 0, 0, rc.right - rc.left, rc.bottom - rc.top,
        SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

static void ToggleFullscreen(HWND hwnd)
{
    MONITORINFO mi;
    DWORD style;
    DWORD exStyle;

    if (!g_fullscreen)
    {
        g_savedWindowStyle = (DWORD)GetWindowLongPtr(hwnd, GWL_STYLE);
        g_savedWindowExStyle = (DWORD)GetWindowLongPtr(hwnd, GWL_EXSTYLE);
        g_savedWindowPlacement.length = sizeof(WINDOWPLACEMENT);
        GetWindowPlacement(hwnd, &g_savedWindowPlacement);

        mi.cbSize = sizeof(mi);
        if (!GetMonitorInfoA(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &mi))
            return;

        style = g_savedWindowStyle;
        style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZE | WS_MAXIMIZE | WS_SYSMENU);

        exStyle = g_savedWindowExStyle;
        exStyle &= ~(WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE);

        SetWindowLongPtr(hwnd, GWL_STYLE, (LONG_PTR)style);
        SetWindowLongPtr(hwnd, GWL_EXSTYLE, (LONG_PTR)exStyle);

        SetWindowPos(hwnd, HWND_TOPMOST,
            mi.rcMonitor.left,
            mi.rcMonitor.top,
            mi.rcMonitor.right - mi.rcMonitor.left,
            mi.rcMonitor.bottom - mi.rcMonitor.top,
            SWP_NOOWNERZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW);

        ApplyDarkModeToWindow(hwnd);

        g_fullscreen = 1;
        SetCursor(NULL);
    }
    else
    {
        SetWindowLongPtr(hwnd, GWL_STYLE, (LONG_PTR)g_savedWindowStyle);
        SetWindowLongPtr(hwnd, GWL_EXSTYLE, (LONG_PTR)g_savedWindowExStyle);
        SetWindowPlacement(hwnd, &g_savedWindowPlacement);

        SetWindowPos(hwnd, HWND_NOTOPMOST,
            0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW);

        ApplyDarkModeToWindow(hwnd);

        g_fullscreen = 0;
        SetCursor(g_arrowCursor ? g_arrowCursor : LoadCursor(NULL, IDC_ARROW));
    }

    FitFontToClient(hwnd);
    InvalidateRect(hwnd, NULL, FALSE);
}

static void PaintAvanorToDC(HWND hwnd, HDC hdc)
{
    RECT client;
    RECT terminal;
    HBRUSH bgBrush;
    HBRUSH termBrush;
    HFONT oldFont;
    int x;
    int y;

    GetClientRect(hwnd, &client);

    /* ===============================
    ** fill the whole client area with 
    ** the Avanor terminal background
    ** ===============================
    */
    if (g_tileBackgroundOn && g_tileBitmap)
    {
        TileBackgroundToDC(hdc, &client);
    }
    else
    {
        bgBrush = CreateSolidBrush(RGB(5, 8, 12));
        FillRect(hdc, &client, bgBrush);
        DeleteObject(bgBrush);
    }

    terminal.left = g_termLeft;
    terminal.top = g_termTop;
    terminal.right = g_termLeft + (LONG)(size_x * g_charW);
    terminal.bottom = g_termTop + (LONG)(size_y * g_charH);

    if (!(g_tileBackgroundOn && g_tileBitmap))
    {
        termBrush = CreateSolidBrush(RGB(5, 8, 12));
        FillRect(hdc, &terminal, termBrush);
        DeleteObject(termBrush);
    }

    oldFont = (HFONT)SelectObject(hdc, g_font);
    SetBkMode(hdc, TRANSPARENT);

    EnterCriticalSection(&g_screenLock);

    for (y = 0; y < size_y; y++)
    {
        for (x = 0; x < size_x; x++)
        {
            AV_CELL cell = vscreen[x + y * size_x];
            char ch = cell.ch;

            if ((unsigned char)ch < 32)
                ch = ' ';

            if (ch != ' ')
            {
                SetTextColor(hdc, AvColor(cell.attr));
                TextOutA(hdc, g_termLeft + x * g_charW, g_termTop + y * g_charH, &ch, 1);
            }
        }
    }

    if (draw_cursor_line && cursor_visible && cursor_pos_x >= 0 && cursor_pos_x < size_x && cursor_pos_y >= 0 && cursor_pos_y < size_y)
    {
        HPEN pen = CreatePen(PS_SOLID, 1, RGB(220, 220, 220));
        HPEN oldPen = (HPEN)SelectObject(hdc, pen);
        int cx = g_termLeft + cursor_pos_x * g_charW;
        int cy = g_termTop + cursor_pos_y * g_charH;

        MoveToEx(hdc, cx, cy + g_charH - 2, NULL);
        LineTo(hdc, cx + g_charW, cy + g_charH - 2);

        SelectObject(hdc, oldPen);
        DeleteObject(pen);
    }

    LeaveCriticalSection(&g_screenLock);

    SelectObject(hdc, oldFont);
}


static void PaintAvanor(HWND hwnd, HDC hdc)
{
    RECT client;
    HDC memdc;
    HBITMAP bitmap;
    HBITMAP oldBitmap;
    int width;
    int height;

    GetClientRect(hwnd, &client);
    width = client.right - client.left;
    height = client.bottom - client.top;

    if (width <= 0 || height <= 0)
        return;

    memdc = CreateCompatibleDC(hdc);
    if (!memdc)
    {
        PaintAvanorToDC(hwnd, hdc);
        return;
    }

    bitmap = CreateCompatibleBitmap(hdc, width, height);
    if (!bitmap)
    {
        DeleteDC(memdc);
        PaintAvanorToDC(hwnd, hdc);
        return;
    }

    oldBitmap = (HBITMAP)SelectObject(memdc, bitmap);

    PaintAvanorToDC(hwnd, memdc);
    BitBlt(hdc, 0, 0, width, height, memdc, 0, 0, SRCCOPY);

    SelectObject(memdc, oldBitmap);
    DeleteObject(bitmap);
    DeleteDC(memdc);
}

static int MapSpecialKey(WPARAM vk)
{
    switch (vk)
    {
        case VK_UP:     return KEY_UP;
        case VK_DOWN:   return KEY_DOWN;
        case VK_LEFT:   return KEY_LEFT;
        case VK_RIGHT:  return KEY_RIGHT;
        case VK_HOME:   return KEY_HOME;
        case VK_END:    return KEY_END;
        case VK_PRIOR:  return KEY_PGUP;
        case VK_NEXT:   return KEY_PGDOWN;
        case VK_CLEAR:  return KEY_CENTER;
        case VK_NUMPAD5:return KEY_CENTER;
        default:        return KEY_UNKNOWN;
    }
}

static LRESULT CALLBACK AvanorWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        case WM_CREATE:
            MeasureFont(hwnd);
            SizeWindowForScreen(hwnd);
            SetFocus(hwnd);
            return 0;

        case WM_SIZE:
            FitFontToClient(hwnd);
            InvalidateRect(hwnd, NULL, FALSE);
            return 0;

        case WM_SETFOCUS:
            CreateCaret(hwnd, NULL, g_charW, 2);
            return 0;

        case WM_KILLFOCUS:
            DestroyCaret();
            return 0;

        case WM_SETCURSOR:
          
            /* =====================
            ** hide the mouse cursor
            ** during full-screen
            ** =====================
            */
            if (g_fullscreen && LOWORD(lParam) == HTCLIENT)
            {
                SetCursor(NULL);
                return TRUE;
            }
            break;

        case WM_KEYDOWN:
        case WM_SYSKEYDOWN:
        {
            int key;

            if (wParam == VK_F11)
            {
                if ((lParam & 0x40000000) == 0)
                    ToggleFullscreen(hwnd);
                return 0;
            }

            /* ============================
            ** F6 toggles tiled background
            ** ============================
            */
            if (wParam == VK_F6)
            {
                if ((lParam & 0x40000000) == 0)
                    ToggleTileBackground(hwnd);
                return 0;
            }

            /* ========================
            ** F7/F8 switch fonts live
            ** ========================
            */
            if (wParam == VK_F7)
            {
                if ((lParam & 0x40000000) == 0)
                    SwitchAvanorFont(hwnd, -1);
                return 0;
            }

            if (wParam == VK_F8)
            {
                if ((lParam & 0x40000000) == 0)
                    SwitchAvanorFont(hwnd, 1);
                return 0;
            }

           /* =============================
           ** alt-enter toggles full screen
           ** F11 also toggles
           ** =============================
           */
            if (msg == WM_SYSKEYDOWN && wParam == VK_RETURN && (lParam & 0x20000000))
            {
                if ((lParam & 0x40000000) == 0)
                    ToggleFullscreen(hwnd);
                return 0;
            }

            key = MapSpecialKey(wParam);
            if (key != KEY_UNKNOWN)
            {
                QueueKey(key);
                return 0;
            }
            break;
        }

        case WM_SYSCHAR:
           
            /* =========================
            ** stop windows from chiming
            ** on alt-enter
            ** =========================
            */
            if (wParam == VK_RETURN || wParam == 13)
                return 0;
            break;

        case WM_CHAR:
            if (wParam > 0 && wParam < 256)
            {
                QueueKey((int)wParam);
                return 0;
            }
            break;

        case WM_THEMECHANGED:
        case WM_SETTINGCHANGE:
            ApplyDarkModeToWindow(hwnd);
            InvalidateRect(hwnd, NULL, FALSE);
            return 0;

        case AV_WM_REFRESH:
            InterlockedExchange(&g_refreshPending, 0);
            InvalidateRect(hwnd, NULL, FALSE);
            return 0;

        case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            PaintAvanor(hwnd, hdc);
            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_ERASEBKGND:
        {
            RECT client;
            HBRUSH brush;

            GetClientRect(hwnd, &client);
            brush = g_backgroundBrush ? g_backgroundBrush : (HBRUSH)GetStockObject(BLACK_BRUSH);
            FillRect((HDC)wParam, &client, brush);
            return 1;
        }

        case WM_CLOSE:
            InterlockedExchange(&g_closing, 1);
            QueueKey(KEY_ESC);
            if (!InterlockedCompareExchange(&g_finiting, 0, 0))
                ExitProcess(0);
            DestroyWindow(hwnd);
            return 0;

        case WM_DESTROY:
            SetCursor(g_arrowCursor ? g_arrowCursor : LoadCursor(NULL, IDC_ARROW));
            g_hwnd = NULL;
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

static void TrySetDpiAware()
{
    typedef BOOL (WINAPI *SETDPIAWAREPROC)(void);
    HMODULE user32 = GetModuleHandleA("user32.dll");
    if (user32)
    {
        SETDPIAWAREPROC pSetProcessDPIAware =
            (SETDPIAWAREPROC)GetProcAddress(user32, "SetProcessDPIAware");
        if (pSetProcessDPIAware)
            pSetProcessDPIAware();
    }
}

static HICON LoadAvanorIcon()
{
    HICON icon;

    icon = LoadIconA(g_hInstance, MAKEINTRESOURCEA(IDI_AVANOR_ICON));
    if (!icon)
        icon = LoadIcon(NULL, IDI_APPLICATION);

    return icon;
}

static DWORD WINAPI WindowThreadProc(LPVOID)
{
    WNDCLASSA wc;
    MSG msg;
    HICON appIcon;

    TrySetDpiAware();

    ZeroMemory(&wc, sizeof(wc));

    if (!g_backgroundBrush)
        g_backgroundBrush = CreateSolidBrush(RGB(5, 8, 12));

    if (!g_arrowCursor)
        g_arrowCursor = LoadCursor(NULL, IDC_ARROW);

    appIcon = LoadAvanorIcon();

    wc.lpfnWndProc = AvanorWndProc;
    wc.hInstance = g_hInstance;
    wc.hCursor = g_arrowCursor;
    wc.hIcon = appIcon;
    wc.hbrBackground = g_backgroundBrush ? g_backgroundBrush : (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = "AvanorWinAPIWindow";

    RegisterClassA(&wc);

    g_hwnd = CreateWindowExA(
        0,
        wc.lpszClassName,
        "Avanor",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        900, 600,
        NULL, NULL, g_hInstance, NULL);

    if (!g_hwnd)
    {
        SetEvent(g_windowReady);
        return 0;
    }

    SendMessage(g_hwnd, WM_SETICON, ICON_BIG, (LPARAM)appIcon);
    SendMessage(g_hwnd, WM_SETICON, ICON_SMALL, (LPARAM)appIcon);

    ApplyDarkModeToWindow(g_hwnd);

    if (g_startFullscreen)
        ToggleFullscreen(g_hwnd);

    ShowWindow(g_hwnd, SW_SHOW);
    UpdateWindow(g_hwnd);
    SetEvent(g_windowReady);

    while (GetMessage(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}

void vInit()
{
    size_x = 80;
    size_y = 25;

    InitializeCriticalSection(&g_screenLock);
    InitializeCriticalSection(&g_keyLock);

    g_keyReady = CreateEvent(NULL, TRUE, FALSE, NULL);
    g_windowReady = CreateEvent(NULL, TRUE, FALSE, NULL);

    vscreen = new AV_CELL[size_x * size_y];
    vClrScr();

    LoadPrivateFonts();
    LoadTileBackground();

    if (g_tileBitmap)
        g_tileBackgroundOn = 1;

    g_hInstance = GetModuleHandle(NULL);
    g_windowThread = CreateThread(NULL, 0, WindowThreadProc, NULL, 0, &g_windowThreadId);

    if (g_windowThread)
        WaitForSingleObject(g_windowReady, INFINITE);

    if (!g_hwnd)
    {
        MessageBoxA(NULL, "Could not create the Avanor WinAPI window.", "Avanor", MB_ICONERROR | MB_OK);
        ExitProcess(1);
    }
}

void vClrScr()
{
    int i;

    if (!vscreen)
        return;

    EnterCriticalSection(&g_screenLock);
    for (i = 0; i < size_x * size_y; i++)
    {
        vscreen[i].ch = ' ';
        vscreen[i].attr = 7;
    }
    LeaveCriticalSection(&g_screenLock);
}

void vFinit()
{
    SetCursor(g_arrowCursor ? g_arrowCursor : LoadCursor(NULL, IDC_ARROW));

    InterlockedExchange(&g_finiting, 1);
    InterlockedExchange(&g_closing, 1);

    if (g_hwnd)
        PostMessage(g_hwnd, WM_CLOSE, 0, 0);

    if (g_windowThread)
    {
        WaitForSingleObject(g_windowThread, 1000);
        CloseHandle(g_windowThread);
        g_windowThread = NULL;
    }

    if (g_font)
    {
        DeleteObject(g_font);
        g_font = NULL;
    }

    if (g_backgroundBrush)
    {
        DeleteObject(g_backgroundBrush);
        g_backgroundBrush = NULL;
    }

    UnloadTileBackground();
    UnloadPrivateFonts();

    if (g_keyReady)
    {
        CloseHandle(g_keyReady);
        g_keyReady = NULL;
    }

    if (g_windowReady)
    {
        CloseHandle(g_windowReady);
        g_windowReady = NULL;
    }

    delete [] vscreen;
    vscreen = NULL;

    DeleteCriticalSection(&g_screenLock);
    DeleteCriticalSection(&g_keyLock);
}

void vRefresh()
{
    if (g_hwnd && InterlockedExchange(&g_refreshPending, 1) == 0)
        PostMessage(g_hwnd, AV_WM_REFRESH, 0, 0);
}

void vPutCh(int x, int y, char ch, int attr)
{
    if (!vscreen)
        return;

    if (x < 0 || y < 0 || x >= size_x || y >= size_y)
        return;

    EnterCriticalSection(&g_screenLock);
    vscreen[x + y * size_x].ch = ch;
    vscreen[x + y * size_x].attr = (unsigned char)(attr & 15);
    LeaveCriticalSection(&g_screenLock);
}

char vTestCh(int x, int y)
{
    char ch = ' ';

    if (!vscreen)
        return ' ';

    if (x < 0 || y < 0 || x >= size_x || y >= size_y)
        return ' ';

    EnterCriticalSection(&g_screenLock);
    ch = vscreen[x + y * size_x].ch;
    LeaveCriticalSection(&g_screenLock);

    return ch;
}

void vPutCh(int x, int y, char ch)
{
    if (!vscreen)
        return;

    if (x < 0 || y < 0 || x >= size_x || y >= size_y)
        return;

    EnterCriticalSection(&g_screenLock);
    vscreen[x + y * size_x].ch = ch;
    LeaveCriticalSection(&g_screenLock);
}

void vGotoXY(int x, int y)
{
    cursor_pos_x = x;
    cursor_pos_y = y;
}

void vXGotoXY(int x, int y)
{
    cursor_pos_x = x;
    cursor_pos_y = y;
    cursor_visible = 1;
    vRefresh();
}

void vGetCursorPos(int * x, int * y)
{
    *x = cursor_pos_x;
    *y = cursor_pos_y;
}

void vHideCursor()
{
    cursor_visible = 0;
    vRefresh();
}

void vSetAttr(int color)
{
    current_attr = color;
}

void vClrEol()
{
    while (cursor_pos_x < size_x)
    {
        vPutCh(cursor_pos_x, cursor_pos_y, ' ');
        cursor_pos_x++;
    }
}

void vPutS(const char * s)
{
    if(cursor_pos_y >= size_y) cursor_pos_x = cursor_pos_y = 0;

    while(true)
    {
        char ch = *s++;
        switch(ch)
        {
            case 0 :
                return;
            case 31 :
                vSetAttr(*s++); break;
            case 13 :
            case '\n' :
                cursor_pos_x = 0;
                if(++cursor_pos_y >= size_y) cursor_pos_y = 0;
                break;
            default :
            {
                if(cursor_pos_x >= size_x)
                {
                    cursor_pos_x = 0;
                    if(++cursor_pos_y >= size_y) cursor_pos_y = 0;
                }
                vPutCh(cursor_pos_x++, cursor_pos_y, ch, current_attr);
            }
        }
    }
}

void vFPutS(FILE * f, const char * s)
{
    int pos = 0;
    while (s[pos])
    {
        if (s[pos] == 31)
        {
            pos += 2;
            continue;
        }
        fprintf(f, "%c", s[pos]);
        pos++;
    }
}

int vGetS(char * s, int buffer_size)
{
    int cx;
    int cy;
    int buffer_pos = 0;
    int ch;

    vGetCursorPos(&cx, &cy);
    strcpy(s, "");

    do
    {
        vXGotoXY(cx + (int)strlen(s), cy);
        ch = vGetch();

        if (ch == 13 || ch == 27)
        {
            s[buffer_pos] = 0;
            return ch == 13;
        }

        if (ch == 8 && buffer_pos > 0)
        {
            s[buffer_pos - 1] = ' ';
            s[buffer_pos] = 0;
            vGotoXY(cx, cy);
            vPutS(s);
            buffer_pos--;
        }
        else if (ch >= 32 && ch < 127)
        {
            s[buffer_pos++] = (char)ch;
        }

        s[buffer_pos] = 0;
        vGotoXY(cx, cy);
        vPutS(s);
        vRefresh();
    }
    while (buffer_pos < buffer_size - 1);

    return 1;
}

void vDelay(int n)
{
    if (n > 0)
        Sleep((DWORD)n);
}

int vKbhit()
{
    return QueueHasKey();
}

int vGetch()
{
    int key;

    while (1)
    {
        if (DequeueKey(&key))
            return key;

        if (InterlockedCompareExchange(&g_closing, 0, 0))
            return KEY_ESC;

        WaitForSingleObject(g_keyReady, INFINITE);
    }
}

int vXGetch(char * ch_buf)
{
    int slen = (int)strlen(ch_buf);
    while (1)
    {
        int ch = vGetch();
        for (int i = 0; i < slen; i++)
        {
            if (ch == ch_buf[i])
                return ch;
        }
        if (ch == KEY_ESC)
            return 0;
    }
}

static unsigned long randx;

void vRandSeed(unsigned long seed)
{
    randx = seed;
}

#define X_RAND_A   0x000343FDUL
#define X_RAND_B   0x00269EC3UL
#define X_RAND_MAX 0x7FFFFFFFUL

long vRand()
{
    randx = randx * X_RAND_A + X_RAND_B;
    unsigned long randhigh = randx & 0x7FFF0000;
    randx = randx * X_RAND_A + X_RAND_B;
    unsigned long randlow = randx >> 16;
    return randhigh | randlow;
}

long vRand(unsigned long n)
{
    assert(n > 0);
    if (n > 0x8000)
    {
        assert(n <= X_RAND_MAX + 1);
        randx = randx * X_RAND_A + X_RAND_B;
        unsigned long randhigh = randx & 0x7FFF0000;
        randx = randx * X_RAND_A + X_RAND_B;
        unsigned long randlow = randx >> 16;
        return (randhigh | randlow) % n;
    }
    else
    {
        randx = randx * X_RAND_A + X_RAND_B;
        return (randx >> 16) % n;
    }
}

V_BUFFER::V_BUFFER()
{
    buffer = new char[size_x * size_y * sizeof(AV_CELL)];
}

V_BUFFER::~V_BUFFER()
{
    delete [] buffer;
}

void vStore(V_BUFFER * buf)
{
    EnterCriticalSection(&g_screenLock);
    memcpy(buf->buffer, vscreen, size_x * size_y * sizeof(AV_CELL));
    LeaveCriticalSection(&g_screenLock);
}

void vRestore(V_BUFFER * buf)
{
    EnterCriticalSection(&g_screenLock);
    memcpy(vscreen, buf->buffer, size_x * size_y * sizeof(AV_CELL));
    LeaveCriticalSection(&g_screenLock);
    vRefresh();
}

static char path_buffer[1024];

char *vMakePath(char *prefix, char *filename)
{
    sprintf(path_buffer, "%s%s", prefix, filename);
    return path_buffer;
}
