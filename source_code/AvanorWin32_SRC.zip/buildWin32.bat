@echo off
setlocal

echo Building AvanorWin32...

where cl >nul 2>nul
if errorlevel 1 (
    echo.
    echo ERROR: cl.exe was not found.
    echo Run this from a Visual Studio Developer Command Prompt.
    echo.
    exit /b 1
)

where rc >nul 2>nul
if errorlevel 1 (
    echo.
    echo ERROR: rc.exe was not found.
    echo Run this from a Visual Studio Developer Command Prompt.
    echo.
    exit /b 1
)

if not exist obj_winapi mkdir obj_winapi
if not exist bin mkdir bin

cl /nologo /EHsc /O2 /W3 ^
   /DWIN32 /D_WINDOWS /D_CRT_SECURE_NO_WARNINGS ^
   /Iglobal /Imap /Icreature /Iengine /Ihelpers /Iitem /Imagic /Iother /Igame /I. ^
   /c @winapi_sources.rsp /Foobj_winapi\

if errorlevel 1 (
    echo.
    echo Compile failed.
    exit /b 1
)

rc /nologo /i . /fo obj_winapi\avanor_icon.res avanor_icon.rc

if errorlevel 1 (
    echo.
    echo Resource compile failed.
    exit /b 1
)

link /nologo ^
     /OUT:bin\AvanorWin32.exe ^
     /SUBSYSTEM:WINDOWS ^
     /ENTRY:mainCRTStartup ^
     @winapi_objects.rsp obj_winapi\avanor_icon.res user32.lib gdi32.lib

if errorlevel 1 (
    echo.
    echo Link failed.
    exit /b 1
)

xcopy /E /I /Y manual bin\manual >nul
copy /Y gpl.txt bin\gpl.txt >nul
copy /Y changes.txt bin\changes.txt >nul

rem Keep font files out of the main bin folder.
rem Runtime font loading now looks in bin\fonts\.
if not exist bin\fonts mkdir bin\fonts
if exist bin\*.ttf del /q bin\*.ttf >nul 2>nul
if exist bin\*.otf del /q bin\*.otf >nul 2>nul
if exist bin\fonts\*.ttf del /q bin\fonts\*.ttf >nul 2>nul
if exist bin\fonts\*.otf del /q bin\fonts\*.otf >nul 2>nul
if exist fonts\*.ttf for %%F in (fonts\*.ttf) do copy /Y "%%F" "bin\fonts\%%~nxF" >nul
if exist fonts\*.otf for %%F in (fonts\*.otf) do copy /Y "%%F" "bin\fonts\%%~nxF" >nul

rem Keep background bitmaps out of the main bin folder.
rem Runtime background loading now looks in bin\bkground\.
if not exist bin\bkground mkdir bin\bkground
if exist bin\*.bmp del /q bin\*.bmp >nul 2>nul
if exist bin\bkground\*.bmp del /q bin\bkground\*.bmp >nul 2>nul
if exist bkground\*.bmp for %%F in (bkground\*.bmp) do copy /Y "%%F" "bin\bkground\%%~nxF" >nul

echo.
echo Build complete: bin\AvanorWin32.exe
echo.
